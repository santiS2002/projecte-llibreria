package IUserActions;

public interface IUserActions {
    boolean borrowBook(String mail,String bookTitle);
    boolean returnBook(String mail,String bookTitle);
    void seeBooksBorrowed(String mail);
    void seeAvailableBooks();
}
