package IAdminActions;

import book.Book;

public interface IAdminActions {
    boolean addBook(Book book);
    boolean deleteBook(int id);
}
